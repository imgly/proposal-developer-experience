// We need this to fill this later with module declarations
export interface ToolSchema {

}




type ToolName = keyof ToolSchema;

type ToolHandler<T extends ToolName> = (
  ...params: ToolSchema[T]['params']
) => ToolSchema[T]['result']; // | Promise<ToolSchema[T]['result']>;

export type ToolFn<T> = (...args: T['params']) => T['result'];



// const registry: Partial<{
//   [K in ToolName]: ToolHandler<K>;
// }> = {};

// export function register<T extends ToolName>(
//   name: T,
//   handler: ToolHandler<T>
// ) {
//   registry[name] = handler;
// }


// // type ToolFn<T> = (params: T['params']) => T['result'] | Promise<T['result']>;



// function invoke<T extends keyof ToolSchema>(
//   name: T,
//   params: ToolSchema[T]['params']
// ): ToolSchema[T]['result'] {
//   console.log(`Invoking ${name}`, params);

//   // Dispatch logic
//   const handler = registry[name]
//   if (handler === undefined) throw new Error("Handler not found")
//   return handler(params)
// }


// type Call = {
//   [K in ToolName]: ToolFn<ToolSchema[K]>;
// } & {
//   call: typeof invoke;
//   handle: typeof register;
// };
// export let call: Call = {
//   // attach tool functions dynamically
//   ...(Object.fromEntries(
//     Object.keys(registry).map((key) => [
//       key,
//       (...args: any[]) => invoke(key as ToolName, ...args),
//     ])
//   ) as any),

//   call: invoke,
//   handle: register,
// };


// export default call


type Tools = {
  [K in ToolName]: ToolFn<ToolSchema[K]>;
} & {
  call: <T extends ToolName>(
    name: T,
    ...params: ToolSchema[T]['params']
  ) => ToolSchema[T]['result];

  handle: <T extends ToolName>(
    name: T,
    handler: ToolHandler<T>
  ) => void;
};

// 👇 dynamic call object (mutable)
const tools = {} as Tools;

tools.handle = function <T extends ToolName>(
  name: T,
  handler: ToolHandler<T>
) {
  // Store the raw function directly
  (tools as any)[name] = (...args: any[]) => {
    return tools.call(name, ...args); // central dispatcher
  };

  // Also store the raw handler internally
  (tools._handlers ??= {})[name] = handler;
};


tools.call = function <T extends ToolName>(
  name: T,
  ...params: ToolSchema[T]['params']
): ToolSchema[T]['result'] {
  const handlers = (tools as any)._handlers as {
    [K in ToolName]: ToolHandler<K>;
  };

  const fn = handlers?.[name];
  if (!fn) throw new Error(`Handler for "${name}" not registered`);

  return fn(...params);
};


export default tools;
